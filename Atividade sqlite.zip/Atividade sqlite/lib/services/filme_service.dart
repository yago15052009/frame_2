import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/filme.dart';

class FilmeService {
  static Database? _db;

  Future<Database> get db async {
    _db ??= await _abrirBanco();
    return _db!;
  }

  Future<Database> _abrirBanco() async {
    final caminho = join(await getDatabasesPath(), 'filmes.db');
    return openDatabase(
      caminho,
      version: 1,
      onCreate: (db, _) => db.execute(
        'CREATE TABLE filmes (id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL, assistido INTEGER NOT NULL)',
      ),
    );
  }

  Future<int> inserir(Filme filme) async {
    final banco = await db;
    return banco.insert('filmes', filme.toMap());
  }

  Future<List<Filme>> listar() async {
    final banco = await db;
    final resultado = await banco.query('filmes');
    return resultado.map(Filme.fromMap).toList();
  }

  Future<void> atualizarAssistido(Filme filme) async {
    final banco = await db;
    await banco.update(
      'filmes',
      {'assistido': filme.assistido ? 1 : 0},
      where: 'id = ?',
      whereArgs: [filme.id],
    );
  }
}
