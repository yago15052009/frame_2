import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/filme_viewmodel.dart';

class PaginaInicial extends StatefulWidget {
  const PaginaInicial({super.key});

  @override
  State<PaginaInicial> createState() => _PaginaInicialState();
}

class _PaginaInicialState extends State<PaginaInicial> {
  final _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<FilmeViewModel>().carregarFilmes();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _adicionar() {
    final titulo = _controller.text.trim();
    if (titulo.isEmpty) return;
    context.read<FilmeViewModel>().adicionarFilme(titulo);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<FilmeViewModel>();

    return Scaffold(
      appBar: AppBar(title: const Text('Minha Lista de Filmes')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                hintText: 'Digite o nome do filme',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _adicionar,
              child: const Text('Adicionar'),
            ),
            const Divider(height: 24),
            Expanded(
              child: ListView.builder(
                itemCount: vm.filmes.length,
                itemBuilder: (_, i) {
                  final filme = vm.filmes[i];
                  return ListTile(
                    leading: Text('${i + 1}'),
                    title: Text(
                      filme.titulo,
                      style: TextStyle(
                        decoration: filme.assistido
                            ? TextDecoration.lineThrough
                            : TextDecoration.none,
                      ),
                    ),
                    trailing: Checkbox(
                      value: filme.assistido,
                      onChanged: (_) =>
                          context.read<FilmeViewModel>().alterarAssistido(filme),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
