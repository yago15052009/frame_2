class Filme {
  final int? id;
  final String titulo;
  bool assistido;

  Filme({this.id, required this.titulo, this.assistido = false});

  Map<String, dynamic> toMap() => {
        'id': id,
        'titulo': titulo,
        'assistido': assistido ? 1 : 0,
      };

  factory Filme.fromMap(Map<String, dynamic> map) => Filme(
        id: map['id'],
        titulo: map['titulo'],
        assistido: map['assistido'] == 1,
      );
}
