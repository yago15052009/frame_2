import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'viewmodels/filme_viewmodel.dart';
import 'pages/pagina_inicial.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => FilmeViewModel(),
      child: const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: PaginaInicial(),
      ),
    ),
  );
}
