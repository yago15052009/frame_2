import 'package:flutter/foundation.dart';
import '../models/filme.dart';
import '../services/filme_service.dart';

class FilmeViewModel extends ChangeNotifier {
  final FilmeService _service = FilmeService();
  List<Filme> filmes = [];

  Future<void> carregarFilmes() async {
    filmes = await _service.listar();
    notifyListeners();
  }

  Future<void> adicionarFilme(String titulo) async {
    final filme = Filme(titulo: titulo);
    final id = await _service.inserir(filme);
    filmes.add(Filme(id: id, titulo: titulo));
    notifyListeners();
  }

  Future<void> alterarAssistido(Filme filme) async {
    filme.assistido = !filme.assistido;
    await _service.atualizarAssistido(filme);
    notifyListeners();
  }
}
