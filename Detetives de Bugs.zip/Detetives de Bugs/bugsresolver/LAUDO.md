# LAUDO.md — Operação Resgate: Detetives de Bugs

---

## Bug 01

**Arquivo:** `lib/models/ocorrencia.dart`
**Sintoma:** O campo `autorId` da ocorrência sempre recebia o nome do autor em vez do ID, impossibilitando a verificação de propriedade.
**Causa:** `d['autorNome']` foi usado duas vezes; o campo `autorId` nunca era lido do Firestore.
**Correção:** Alterado para `d['autorId'] as String? ?? ''`.
**Teste:** Registrou-se uma ocorrência e verificou-se no Firestore que `autorId` contém o e-mail do usuário, não o nome.

---

## Bug 02

**Arquivo:** `lib/models/ocorrencia.dart`
**Sintoma:** Ocorrências marcadas como resolvidas apareciam como "Em aberto" e vice-versa.
**Causa:** O valor booleano `resolvido` era negado com `!` ao ser lido do Firestore, invertendo o estado real.
**Correção:** Removido o operador `!`: `resolvido: d['resolvido'] as bool? ?? false`.
**Teste:** Marcou-se um item como resolvido; o status exibido passou a ser "Resolvido" corretamente.

---

## Bug 03

**Arquivo:** `lib/services/central_service.dart`
**Sintoma:** Os registros mais antigos apareciam no topo da lista em vez dos mais recentes.
**Causa:** `orderBy('criadoEm', descending: false)` ordenava do mais antigo para o mais novo.
**Correção:** Alterado para `descending: true`.
**Teste:** Após registrar dois objetos, o segundo apareceu no topo da lista.

---

## Bug 04

**Arquivo:** `lib/services/central_service.dart`
**Sintoma:** O botão "Marcar como resolvido" nunca aparecia para o dono da ocorrência; a verificação de autorização sempre falhava.
**Causa:** `u.uid` (UID do Firebase Auth) era comparado com `item.autorId` (que armazena o e-mail), então nunca eram iguais.
**Correção:** Alterado para `u.email != item.autorId`.
**Teste:** O dono da ocorrência passou a ver o botão de alterar status; outros usuários não veem.

---

## Bug 05

**Arquivo:** `lib/services/central_service.dart`
**Sintoma:** Ao clicar em "Marcar como resolvido", o status não mudava — o Firestore recebia o mesmo valor já armazenado.
**Causa:** `update({'resolvido': item.resolvido})` gravava o valor atual sem invertê-lo.
**Correção:** Alterado para `update({'resolvido': !item.resolvido})`.
**Teste:** Clicar no botão alternava o status entre resolvido e em aberto corretamente.

---

## Bug 06

**Arquivo:** `lib/services/central_service.dart`
**Sintoma:** Pistas enviadas nunca apareciam na ocorrência correta; todas iam para um documento fixo chamado "pistas".
**Causa:** `_db.collection('ocorrencias').doc('pistas')` usava o literal `'pistas'` como ID do documento em vez do ID da ocorrência.
**Correção:** Alterado para `_db.collection('ocorrencias').doc(ocorrenciaId)`.
**Teste:** Enviou-se uma pista em duas ocorrências diferentes; cada pista apareceu apenas na ocorrência correspondente.

---

## Bug 07

**Arquivo:** `lib/pages/central_page.dart`
**Sintoma:** Era possível registrar uma ocorrência sem preencher título ou local — bastava preencher apenas um dos dois campos.
**Causa:** A validação usava `&&` (AND), exigindo que *ambos* estivessem vazios para bloquear o envio.
**Correção:** Alterado para `||` (OR): `if (titulo.text.trim().isEmpty || local.text.trim().isEmpty)`.
**Teste:** Tentou-se registrar com apenas o título preenchido; o snackbar de erro foi exibido corretamente.

---

## Bug 08

**Arquivo:** `lib/pages/central_page.dart`
**Sintoma:** O toggle "Somente não resolvidos" funcionava ao contrário — ativar o switch desativava o filtro.
**Causa:** `onChanged: (value) => setState(() => somenteAbertos = !value)` negava o valor recebido do switch.
**Correção:** Alterado para `somenteAbertos = value`.
**Teste:** Ativar o switch passou a exibir apenas ocorrências em aberto; desativar mostrava todas.

---

## Bug 09

**Arquivo:** `lib/pages/central_page.dart`
**Sintoma:** O filtro "Somente não resolvidos" exibia apenas os itens *resolvidos*, o oposto do esperado.
**Causa:** `todos.where((o) => o.resolvido)` filtrava os resolvidos em vez dos não resolvidos.
**Correção:** Alterado para `todos.where((o) => !o.resolvido)`.
**Teste:** Com o filtro ativo, apenas ocorrências com status "Em aberto" foram exibidas.

---

## Bug 10

**Arquivo:** `lib/pages/central_page.dart`
**Sintoma:** Ao tocar em qualquer ocorrência da lista, a tela de detalhe abria sem dados — título, local e pistas apareciam vazios.
**Causa:** `DetalhePage()` era instanciada sem passar o parâmetro obrigatório `ocorrencia`, causando erro de compilação e tela vazia.
**Correção:** Alterado para `DetalhePage(ocorrencia: o)`.
**Teste:** Ao tocar em uma ocorrência, a tela de detalhe exibiu corretamente título, local, autor e pistas.

---

## Bug 11

**Arquivo:** `lib/pages/detalhe_page.dart`
**Sintoma:** O botão de enviar pista não funcionava quando havia texto digitado; só "funcionava" com o campo vazio (sem enviar nada).
**Causa:** `if (pista.text.trim().isNotEmpty) return;` retornava cedo quando havia conteúdo — lógica completamente invertida.
**Correção:** Alterado para `if (pista.text.trim().isEmpty) return;`.
**Teste:** Digitou-se uma pista e clicou-se em enviar; a pista apareceu na lista em tempo real.

---

## Bug 12

**Arquivo:** `lib/pages/detalhe_page.dart`
**Sintoma:** Mesmo após corrigir o bug 11, as pistas eram enviadas com texto vazio ao Firestore.
**Causa:** `service.enviarPista(widget.ocorrencia.id, '')` passava uma string literal vazia em vez do conteúdo do campo.
**Correção:** Alterado para `service.enviarPista(widget.ocorrencia.id, pista.text)`.
**Teste:** A pista enviada apareceu com o texto correto digitado pelo usuário.
